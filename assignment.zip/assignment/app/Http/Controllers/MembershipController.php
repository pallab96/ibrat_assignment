<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Membership;
use App\Models\Plan;
use App\Models\Master;
use App\Models\Classes;


class MembershipController extends Controller
{
    public function getMembershipById(Request $request){
        //check valid membership
        $isPresent = Membership::where('id',$request->id)->where('deleted_at',NULL);
        if($isPresent->count() == 0)
            return redirect()->back();

        // get deatils if exist

        //get master
        $master_plan = Master::where('membership_id',$isPresent->first()->id)->where('type','plan')->where('deleted_at',NULL)->get();
        $master_class = Master::where('membership_id',$isPresent->first()->id)->where('type','class')->where('deleted_at',NULL)->get();

        $plans = [];
        $classes = [];

        //get plans
        foreach($master_plan as $p){
            $plans[] = Plan::where('id',$p->key_id)->get();
        }  
    
        //get class

        foreach($master_class as $c){
            $classes[] = Classes::where('id',$c->key_id)->get();
        }  
      
        

        $data = [
            'membershipDetails' => $isPresent->first(),
            'plans' => $plans,
            'classes' => $classes
        ];

        // foreach($classes as $c)
        //     echo $c[0]->id; 
        // return dd($classes);
        return view('member',$data);
    }

}
