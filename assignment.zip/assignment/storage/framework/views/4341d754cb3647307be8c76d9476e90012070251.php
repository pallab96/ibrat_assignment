<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <title>Login</title>
    <style>
        html {
        background-color: #56baed;
        }

        body {
        font-family: "Poppins", sans-serif;
        height: 100vh;
        overflow: hidden;
        }

        a {
            color: #92badd;
            display:inline-block;
            text-decoration: none;
            font-weight: 400;
        }

        .wrapper {
        display: flex;
        align-items: center;
        flex-direction: column; 
        justify-content: center;
        width: 100%;
        min-height: 100%;
        padding: 20px;
        }

        #main-content {
            -webkit-border-radius: 10px 10px 10px 10px;
            border-radius: 10px 10px 10px 10px;
            background: #fff;
            padding: 30px;
            width: 90%;
            max-width: 750px;
            position: relative;
            padding: 0px;
            -webkit-box-shadow: 0 30px 60px 0 rgba(0,0,0,0.3);
            box-shadow: 0 30px 60px 0 rgba(0,0,0,0.3);
            text-align: center;
            margin-top: -500px;
        }

        .heading{
            font-size: 21px;
            text-transform: uppercase;
            padding-top: 20px;
        }
        .member-list{
            margin-top: 20px;
            margin-bottom: 20px;
        }
        .member-list .member{
            padding:15px 15px;
            background-color: rgb(236, 235, 235);
            margin: 5px 20px;
            border-radius: 5px;
            text-align: left;
            width: 90%;
            text-decoration: none;
            color:rgb(41, 39, 39)
        }
        .member-list .member:hover{
            background-color: rgb(217, 215, 215);
        }
    </style>
</head>
<body>
<div class="wrapper">
  <div id="main-content">
    <div class="heading">
      <span class="">All Members</span>
    </div>
    <div class="member-list">
        <?php
            $i =0;
        ?>
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="member" href="<?php echo e(route('getMember',1)); ?>">
                <?php echo e(++$i.'. '.$m->membership_name); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </div>


  </div>
</div>
</body>
</html><?php /**PATH /srv/http/assignment/resources/views/index.blade.php ENDPATH**/ ?>