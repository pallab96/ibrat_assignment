<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <style>
        body{
            background-color: #56baed;
        }
        .main-box{
            margin-top:20px;
            background-color: white;
            padding-bottom: 20px;
            -webkit-box-shadow: 0 30px 60px 0 rgba(0,0,0,0.3);
            box-shadow: 0 30px 60px 0 rgba(0,0,0,0.3);
            border-radius: 5px;
            margin-bottom:40px;
        }
        .heading{
            padding:20px 20px;
            color:black;
            font-size: 22px;
        }
        .menu{
            margin-left: 20px;
            border-bottom: solid 1px rgb(236, 234, 234);
            margin-right: 20px;
        }
        .navbar-nav .nav-link{
            padding-left: 40px;
            border-radius: 5px;
        }
        .navbar-nav .nav-item:hover{
            background-color: rgb(219, 219, 219);
        }
        .navbar-expand-lg .navbar-nav .nav-link{
            padding-left: 1rem;
            padding-right: 1rem;
            margin-right: 5px !important;
        }
        .active{
            color:rgb(251, 71, 71) !important;
            background-color: rgb(219, 219, 219);
        }
        .navbar{
            padding-bottom: 0px !important;
            margin-bottom: 0px !important;
            background-color: white;
        }
        .collapse{
            background-color: white;
        }
        .plans, .classes{
            display: none;
        }
        .info, .plans, .classes{
            padding : 20px 20px;
            color:rgb(82, 78, 78);
        }
        .info label, .plans label, .classes label{
            display: block;
            padding-bottom:14px;
        }
        .welcome{
            padding-top:60px;
            font-size: 22px;
            color:rgb(255, 255, 255);
            font-weight: 600;
        }
        .footer{
            margin-left:10px;
        }
        .edit-btn{
            padding:6px 12px;
            background-color: rgb(30, 156, 181);
            color:white;
            border:none;
        }
        .delete-btn{
            padding:6px 12px;
            background-color: rgb(62, 195, 162);
            color:white;
            border:none;
        }
        .plan-img{
            float: right;
            -webkit-box-shadow: 0 30px 60px 0 rgba(0,0,0,0.3);
            box-shadow: 0 30px 60px 0 rgba(0,0,0,0.3);
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="welcome">
                    Hi, <?php echo e($membershipDetails->membership_name); ?>!
                </div>
                <div class="main-box">
                    <div class="heading">
                        BASIC
                    </div>
                    <div class="menu">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                              <div class="navbar-nav">
                                <a class="nav-item nav-link active" href="#" id="info">Details</a>
                                <a class="nav-item nav-link" href="#" id="plans">Plans</a>
                                <a class="nav-item nav-link" href="#" id="classes">Classes</a>
                              </div>
                            </div>
                          </nav>
                    </div>
                    <div class="info">
                        <label for=""><strong>Duration :</strong> <?php echo e($membershipDetails->membership_duration); ?></label>
                        <label for=""><strong>Price :</strong> &#x20B9; <?php echo e(number_format($membershipDetails->membership_duration,2)); ?></label>
                        <label for=""><strong>Classes :</strong> <?php echo e($membershipDetails->membership_classes); ?></label>
                        <label for=""><strong>Discount Percentage :</strong> <?php echo e($membershipDetails->membership_discount_percentage); ?>%</label>
                        <label for=""><strong>Offer Name :</strong> <?php echo e($membershipDetails->membership_offer_name); ?></label>
                        <label for=""><strong>Status :</strong> <?php echo e($membershipDetails->membership_status); ?></label>
                    </div>

                    <div class="plans">
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-lg-8">
                                <label for=""><strong>Name :</strong> <?php echo e($plan[0]->plan_name); ?></label>
                                <label for="" style="text-align:justify;"><strong>Description :</strong> <?php echo $plan[0]->plan_description; ?></label>
                                <label for=""><strong>Tota Work :</strong> <?php echo e($plan[0]->plan_total_workouts); ?></label>
                                <label for="" style="text-align:justify;"><strong>Workout Description :</strong> <?php echo $plan[0]->plan_workouts_description; ?></label>
                                <label for=""><strong>Avg. Duration :</strong> <?php echo e($plan[0]->plan_avg_duration.' '.$plan[0]->duration_unit); ?></label>
                                <label for=""><strong>Total Weeks :</strong> <?php echo e($plan[0]->plan_total_weeks); ?></label>
                                <label for=""><strong>Lavel :</strong> <?php echo e($plan[0]->plan_level); ?></label>
                                <label for=""><strong>Status :</strong> <?php echo e($plan[0]->status); ?></label>
                            </div>
                            <div class="col-lg-4">
                                <img src="<?php echo e($plan[0]->plan_image); ?>" alt="" height="280" width="280" class="plan-img">
                            </div>
                        </div>

                        <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="classes">
                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-lg-8">
                                <label for=""><strong>Name :</strong> <?php echo e($class[0]->class_name); ?></label>
                                <label for=""><strong>Price :</strong> <?php echo e($class[0]->class_price); ?></label>
                                <label for=""><strong>Description :</strong> <?php echo $class[0]->class_short_description; ?></label>
                                <label for=""><strong>Date :</strong> <?php echo e($class[0]->class_date); ?></label>
                                <label for=""><strong>Duration :</strong> <?php echo e($class[0]->class_duration); ?></label>
                                <label for=""><strong>Lavel :</strong> <?php echo e($class[0]->class_level); ?></label>
                                <label for=""><strong>Benefits :</strong> <?php echo $class[0]->class_benefits; ?></label>
                                <label for=""><strong>Trainer :</strong> <?php echo e($class[0]->class_trainer); ?></label>
                                <label for=""><strong>Status :</strong> <?php echo e($class[0]->class_status); ?></label>
                            </div>
                            <div class="col-lg-4">
                                <img src="<?php echo e($class[0]->class_cover); ?>" alt="" height="280" width="280" class="plan-img">
                            </div>
                        </div>

                        <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="footer">
                        <button class="edit-btn"><i class="fas fa-info-circle"></i> Edit</button>
                        <button class="delete-btn"><i class="far fa-trash-alt"></i> Delete</button>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script>
        $('#info').click(function(){
            $(this).addClass('active')
            $('#plans').removeClass('active')
            $('#classes').removeClass('active')
            $('.info').show();
            $('.plans').hide();
            $('.classes').hide();
        })
        $('#plans').click(function(){
            $(this).addClass('active')
            $('#info').removeClass('active')
            $('#classes').removeClass('active')
            $('.plans').show();
            $('.info').hide();
            $('.classes').hide();
        })

        $('#classes').click(function(){
            $(this).addClass('active')
            $('#info').removeClass('active')
            $('#plans').removeClass('active')
            $('.classes').show();
            $('.info').hide();
            $('.plans').hide();
        })
    </script>
</body>
</html><?php /**PATH /srv/http/assignment/resources/views/member.blade.php ENDPATH**/ ?>